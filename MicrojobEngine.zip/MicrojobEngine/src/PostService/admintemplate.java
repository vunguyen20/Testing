package PostService;



import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;

import org.junit.*;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class admintemplate {
  private static WebDriver driver;
  private static String baseUrl;
  private boolean accaeptNextAlert = true;
  private static StringBuffer verificationErrors = new StringBuffer();

  @BeforeClass
  public static void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://lab.enginethemes.com";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void template() throws Exception {
	  driver.get(baseUrl + "/mje/wp-admin");
	  driver.findElement(By.id("user_login")).click();
	  driver.findElement(By.id("user_login")).sendKeys("vund");
	  driver.findElement(By.id("user_pass")).click();
	  driver.findElement(By.id("user_pass")).sendKeys("1");
	  driver.findElement(By.id("wp-submit")).click();
	  driver.findElement(By.linkText("Engine Settings")).click();
	  driver.findElement(By.linkText("SETTINGS")).click();
	  driver.findElement(By.linkText("Payment")).click();
	  driver.findElement(By.cssSelector("#control-payment_package > div > form > div > div.submit > button > span:nth-child(1)")).click();
	  
	  
	  
	  
  }
  
  
  @AfterClass
  public static void  tearDown() throws Exception {
    //driver.quit();
    }
  
}



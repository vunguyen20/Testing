package PostService;


import java.util.concurrent.TimeUnit;

import org.junit.*;

import static org.junit.Assert.*;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class VisiterPostMjeUnSuccessffylyEmailNotYetComfirm {
  private static WebDriver driver;
  private static String baseUrl;
  private static StringBuffer verificationErrors = new StringBuffer();

  @BeforeClass
  public static void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://lab.enginethemes.com";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    driver.manage().window().maximize();
  }
  @Test
  public void UserPostMjobSuccessfullyy() throws Exception {
	  driver.get(baseUrl + "/mje/post-service");
	    driver.findElement(By.cssSelector("div.content-package > p")).click(); 
	    driver.findElement(By.id("user_login")).click();
	    driver.findElement(By.id("user_login")).sendKeys("usercomfirm");
	    driver.findElement(By.id("user_pass")).click();
	    driver.findElement(By.id("user_pass")).sendKeys("123");
	    driver.findElement(By.cssSelector("#signInForm > form > div.inner-form > div.row.clearfix > div.col-lg-6.col-md-6.col-sm-6.col-xs-12.float-right.sign-in-button > button")).click();
	    driver.findElement(By.cssSelector("#step-post > form > div:nth-child(1) > div > input")).click();
	    driver.findElement(By.cssSelector("#step-post > form > div:nth-child(1) > div > input")).sendKeys("mjob service1");
	    driver.findElement(By.cssSelector("#step-post > form > div.form-group.row.clearfix > div.col-lg-6.col-md-6.col-sm-6.col-xs-12.clearfix.delivery-area > div > input ")).click();
	    driver.findElement(By.cssSelector("#step-post > form > div.form-group.row.clearfix > div.col-lg-6.col-md-6.col-sm-6.col-xs-12.clearfix.delivery-area > div > input ")).sendKeys("4");
	    driver.findElement(By.cssSelector("#mjob_category_chosen > a > span ")).click();
	    driver.findElement(By.cssSelector("#mjob_category_chosen > div > div > input[type='text'] ")).click();
	    driver.findElement(By.cssSelector("#mjob_category_chosen > div > div > input[type='text'] ")).sendKeys("business");
	    ((JavascriptExecutor) driver).executeScript("return tinyMCE.activeEditor.setContent('LIke')");
	    driver.findElement(By.cssSelector("#carousel_browse_button > a > img")).click();
	    Runtime.getRuntime().exec("C:\\Users\\vungu\\Desktop\\autoIT\\uploadPic1.exe");
	    Thread.sleep(3000);
	    driver.findElement(By.linkText("Add extra")).click();
	    driver.findElement(By.cssSelector("#step-post > form > div.mjob-extras-wrapper > div > div.col-lg-9.col-md-9.col-sm-9.col-xs-12.no-padding.name-item-extra > input")).sendKeys("Service1");
	    driver.findElement(By.linkText("Add extra")).click();
	     driver.findElement(By.id("skill")).click();
	    driver.findElement(By.id("skill")).sendKeys("html/css");
	    Thread.sleep(3000);
	    driver.findElement(By.cssSelector("button.btn-submit.btn-save")).click();
	    driver.findElement(By.cssSelector("button.btn-submit.btn-save")).click();
	    for (int second = 0;; second++) {
			if (second >= 60)
				fail("timeout");
			try {
				if ("Your account is pending. You have to activate your account to continue this step".equals(driver
						.findElement(By.cssSelector("#toast-container > div > div")).getText()))
					System.out.println("What the hell");
					break;
			} catch (Exception e) {
			}
			Thread.sleep(1000);
		}
  }
  @AfterClass
	public static void tearDown() throws Exception {
		String verificationErrorString = verificationErrors.toString();
		// driver.quit();
		if (!"".equals(verificationErrorString)) {
			System.out.println("Text alert hien thi khong dung");
			fail(verificationErrorString);
			
		}
	}
}









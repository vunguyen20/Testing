package PostService;


import java.util.concurrent.TimeUnit;

import org.junit.*;

import static org.junit.Assert.*;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class UserViewYourPendingMjob {
  private static WebDriver driver;
  private static String baseUrl;
  private static StringBuffer verificationErrors = new StringBuffer();

  @BeforeClass
  public static void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://lab.enginethemes.com";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    driver.manage().window().maximize();
  }
  
  @Test
  public void UserPostMjobSuccessfullyy() throws Exception {
	  driver.get(baseUrl + "/mje/");
	  driver.findElement(By.linkText("Signin")).click();
	    driver.findElement(By.id("user_login")).click();
	    driver.findElement(By.id("user_login")).sendKeys("usermje1");
	    driver.findElement(By.id("user_pass")).click();
	    driver.findElement(By.id("user_pass")).sendKeys("123");
	    driver.findElement(By.cssSelector("#signInForm > form > div.inner-form > div.row.clearfix > div.col-lg-6.col-md-6.col-sm-6.col-xs-12.float-right.sign-in-button > button")).click();
	    driver.findElement(By.cssSelector("#content > div > div > div:nth-child(3) > div:nth-child(2) > div > div > div.view-all > a")).click();
	    assertEquals("PENDING", driver.findElement(By.cssSelector("#content > div > div > div.row.profile > div.col-lg-9.col-md-9.col-sm-12.col-sx-12 > div > ul > li:nth-child(3) > div > div.bookmark > p")).getText());
  }
  @AfterClass
	public static void tearDown() throws Exception {
		String verificationErrorString = verificationErrors.toString();
		// driver.quit();
		if (!"".equals(verificationErrorString)) {
			System.out.println("Text alert hien thi khong dung");
			fail(verificationErrorString);
			
		}
	}
}










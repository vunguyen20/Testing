package authentication;


import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;

import org.junit.*;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JoinUsEmptyEmail {
  private static WebDriver driver;
  private static String baseUrl;
  private boolean acceptNextAlert = true;
  private static StringBuffer verificationErrors = new StringBuffer();

  @BeforeClass
  public static void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://lab.enginethemes.com";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void EmptyEmail() throws Exception {
	  driver.get(baseUrl + "/mje/");
	  driver.findElement(By.xpath("//*[@id='myAccount']/div/ul/li[3]/a")).click();
	    driver.findElement(By.id("user_email")).click();
	    driver.findElement(By.id("user_email")).sendKeys("");
	    driver.findElement(By.cssSelector("button.btn-submit.btn-continue")).click();
	    assertEquals("This field is required.", driver.findElement(By.cssSelector("#signUpFormStep1 > div > div.form-group.clearfix.insert-email > div > p")).getText());
  }
  
  
  @AfterClass
  public void  tearDown() throws Exception {
    //driver.quit();
    }
  
}


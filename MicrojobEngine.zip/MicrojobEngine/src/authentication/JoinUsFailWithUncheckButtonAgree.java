package authentication;


import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;

import org.junit.*;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JoinUsFailWithUncheckButtonAgree {
  private static WebDriver driver;
  private static String baseUrl;
  private boolean acceptNextAlert = true;
  private static StringBuffer verificationErrors = new StringBuffer();

  @BeforeClass
  public static void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://lab.enginethemes.com";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void JoinUsFailWithUncheckButtonAgree1() throws Exception {
	  driver.get(baseUrl + "/mje/");
	  driver.findElement(By.xpath("//*[@id='myAccount']/div/ul/li[3]/a")).click();
	  
	    driver.findElement(By.id("user_email")).click();
	    driver.findElement(By.id("user_email")).sendKeys("mjee@m.m");
	    driver.findElement(By.cssSelector("button.btn-submit.btn-continue")).click();
		driver.findElement(By.cssSelector("#signUpForm > form.form-authentication.et-form > div.inner-form > div.form-group.clearfix > div.input-group > #user_login")).click();
		driver.findElement(By.cssSelector("#signUpForm > form.form-authentication.et-form > div.inner-form > div.form-group.clearfix > div.input-group > #user_login")).sendKeys("ttttt");
	    driver.findElement(By.cssSelector("#signUpForm > form.form-authentication.et-form > div.inner-form > div.form-group.clearfix > div.input-group > #user_pass")).click();
	    driver.findElement(By.cssSelector("#signUpForm > form.form-authentication.et-form > div.inner-form > div.form-group.clearfix > div.input-group > #user_pass")).sendKeys("123");
	    driver.findElement(By.id("repeat_pass")).click();
	    driver.findElement(By.id("repeat_pass")).sendKeys("123");
	    driver.findElement(By.cssSelector("div.form-group.float-right > button.btn-submit")).click();
	    assertEquals("This field is required.", driver.findElement(By.cssSelector("#signUpForm > form > div.inner-form > div:nth-child(4) > div > label > p")).getText());
  }

  
  @AfterClass
  public static void  tearDown() throws Exception {
    //driver.quit();
    }
  
}





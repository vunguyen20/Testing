package authentication;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ JoinUsAlreadyInUseEmail.class, JoinUsEmailRightAndClick.class,
		JoinUsEmailWrongEmailFormat.class, JoinUsEmptyEmail.class,
		JoinUsEmptyUsernamPassRepass.class, JoinUsFailWithRepassNotMatch.class,
		JoinUsFailWithUncheckButtonAgree.class, JoinUsInputUsername420.class,
		JoinUsInputUsernameLowercase.class, JoinUsSuccess.class,
		JoinUsUsenameAlready.class, JoinUsWithPostService.class })
public class AllTests {

}

package authentication;


import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;

import org.junit.*;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JoinUsAlreadyInUseEmail {
  private static WebDriver driver;
  private static String baseUrl;
  private boolean acceptNextAlert = true;
  private static StringBuffer verificationErrors = new StringBuffer();

  @BeforeClass
  public static void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://lab.enginethemes.com";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void JoinUsAlreadyInUseEmail() throws Exception {
	  driver.get(baseUrl + "/mje/");
	  driver.findElement(By.xpath("//*[@id='myAccount']/div/ul/li[3]/a")).click();
	    driver.findElement(By.id("user_email")).click();
	    driver.findElement(By.id("user_email")).sendKeys("mje1@mailinator.com");
	    driver.findElement(By.cssSelector("button.btn-submit.btn-continue")).click();
	    //System.out.println("alert="+ driver.findElement(By.cssSelector("#toast-container > div > div")).getText());
	    for (int second = 0;; second++) {
			if (second >= 60)
				fail("timeout");
			try {
				if ("This email is already used. Please enter a new email.".equals(driver
						.findElement(By.cssSelector("#toast-container > div > div")).getText()))
					break;
			} catch (Exception e) {
			}
			Thread.sleep(1000);
		}
	    
  }
  
  
  @AfterClass
  public static void  tearDown() throws Exception {
    //driver.quit();
    }
  
}



